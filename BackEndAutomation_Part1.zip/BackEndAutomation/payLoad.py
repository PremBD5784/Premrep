def addBookPayload(isbn):
    body = {

        "name": "Learn Appium Automation with Java",
        "isbn": isbn,
        "aisle": "227",
        "author": "John foe"
    }
    return body
